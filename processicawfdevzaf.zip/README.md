# Processica Apps

An Azure Function App which contains functions that are responsible for saving data and generating Power BI Reports on the client's tenant.
